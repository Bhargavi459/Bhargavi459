package in.bank.project;


	import static org.assertj.core.api.Assertions.assertThat;
	import static org.junit.jupiter.api.Assertions.assertNotNull;

	import java.util.List;

	import org.junit.jupiter.api.Test;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
	import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
	import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
	import org.springframework.test.annotation.Rollback;

	import in.bank.project.model.Customer;
	import in.bank.project.repository.BankRepositoryCustomer;


	@DataJpaTest
	@AutoConfigureTestDatabase(replace = Replace.NONE)
	public class CustomerTest {
		
		@Autowired
		private BankRepositoryCustomer CustRepo;
		
		@Test
		@Rollback(false)
		public void testSaveCustomer() {
			Customer customer = new Customer("MBMLA901073043","dileep","901073043","dileep@gmail.com","Dileep@212","gkfpk4425","savings");
			Customer savedcustomer= CustRepo.save(customer);
			assertNotNull(savedcustomer);
			
		}
		
		@Test
		public void testGetAllCustomers() { 
		 List<Customer> customers = (List<Customer>) CustRepo.findAll();
		 for ( Customer customer : customers)
		 {
			 System.out.println(customer.name);
		 }
	    	assertThat(customers).size().isGreaterThan(0);
		}
		
		
}
